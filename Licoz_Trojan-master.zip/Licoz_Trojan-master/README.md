# Licoz_Trojan

# Instalasi
- pkg update && pkg upgrade -y
- pkg install python
- pkg install git
- git clone https://github.com/MRHZx/Licoz_Trojan.git
- cd Licoz_Trojan
- python3 LTD.py

# Cara Penggunaan
- python3 LTD.py "-i" "-p" "-t"

# Contact
- Whatsapp : 085559038021

# For bug Please Report
- y5wmxm7wqoztj3gpigvgd2qvpnhagxcc@dhosting4xxoydyaivckq7tsmtgi4wfs3flpeyitekkmqwu4v4r46syd.onion
